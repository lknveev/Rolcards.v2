# RolCards Stage 3

Stage 3 adds four new playable card classes:

- `ASSASSIN` / numeric `4`
- `PALADIN` / numeric `5`
- `NECROMANCER` / numeric `6`
- `DRUID` / numeric `7`

The existing classes remain:
`NORMAL=0`, `HUNTER=1`, `MAGE=2`, `WARRIOR=3`.

## What changed

- Expanded `CardClass`.
- Added separate card lists for the four new classes.
- `cards.yml` can load cards into all 8 classes.
- Added four new classes to the in-game class selector.
- Added class persistence when players rejoin.
- Added class choices 4-7 to `/rolcards card create`.
- Added serialization for the new classes.
- Added example cards for all four new classes.

## Permissions

The class permissions are:

- `rolcards.class.assassin`
- `rolcards.class.paladin`
- `rolcards.class.necromancer`
- `rolcards.class.druid`

Cards can use their own permissions in `cards.yml`.

## Important

This source was modified from the Stage 2 project. Keep the original MIT license/copyright notice when redistributing it.

A full JAR build was not performed because this source tree does not include all external Spigot/Vault/Lib1711 dependencies needed for compilation.
