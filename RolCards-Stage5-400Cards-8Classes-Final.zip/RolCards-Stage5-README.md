# RolCards Stage 5 — 400 Card Library

Stage 5 expands `cards.yml` to a full configurable card library:

- 50 Normal cards
- 50 Hunter cards
- 50 Mage cards
- 50 Warrior cards
- 50 Assassin cards
- 50 Paladin cards
- 50 Necromancer cards
- 50 Druid cards

**400 configurable cards total.**

The cards use the Stage 4 effect system:
`DAMAGE`, `HEAL`, `DRAW`, `SPAWN`, `MANA`, `STEAL_MANA`, `DAMAGE_ALL`, `HEAL_ALL`, and `DISCARD`.

Class IDs remain:
- 0 Normal
- 1 Hunter
- 2 Mage
- 3 Warrior
- 4 Assassin
- 5 Paladin
- 6 Necromancer
- 7 Druid

All cards are loaded from:
`plugins/RolCards/cards.yml`

The Stage 5 ZIP contains the complete Stage 3 source base plus Stage 4 effect code and the 400-card configuration.

A compiled JAR is not included because the original project depends on external server libraries such as Spigot, Vault, and Lib1711.
