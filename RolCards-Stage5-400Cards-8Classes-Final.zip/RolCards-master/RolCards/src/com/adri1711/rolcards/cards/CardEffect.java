package com.adri1711.rolcards.cards;

public enum CardEffect {
  DAMAGE, HEAL, DRAW, SPAWN,
  MANA, STEAL_MANA, DAMAGE_ALL, HEAL_ALL, DISCARD;
}
