# RolCards Stage 4 — Advanced Card Effects

Stage 4 expands configurable cards beyond the original four effects.

## New effects
- `MANA` — gives the player mana, capped at 5.
- `STEAL_MANA` — steals up to the configured value from the opponent.
- `DAMAGE_ALL` — damages the opponent and all of their monsters.
- `HEAL_ALL` — heals the player and all of their monsters.
- `DISCARD` — removes random cards from the opponent's draw deck.

Existing effects remain supported:
`DAMAGE`, `HEAL`, `DRAW`, `SPAWN`.

These effects work for cards loaded from `plugins/RolCards/cards.yml`.

The source still targets the original RolCards/Spigot 1.12.2 style APIs. A final JAR build requires the project's external dependencies (Spigot, Vault, Lib1711, etc.).
