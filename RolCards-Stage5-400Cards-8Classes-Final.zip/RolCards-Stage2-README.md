# RolCards Stage 2

## Data-driven cards

New cards can be added in `cards.yml` without changing Java.

Classes:
- NORMAL or 0
- HUNTER or 1
- MAGE or 2
- WARRIOR or 3

Effects currently supported:
- DAMAGE
- HEAL
- DRAW
- SPAWN

Example:

```yaml
cards:
  NORMAL:
    Black Hole:
      name: '&8&lBlack Hole'
      price: 5000
      cost: 5
      permission: 'rolcards.class.normal'
      description:
        - '&7Make the enemy take 7 damage.'
      effect: DAMAGE
      value: 7
```

Spawn cards additionally use:

```yaml
effect: SPAWN
value: 1
mob: WOLF
mob-damage: 3
mob-health: 3
```

The original `createdCards` list in `config.yml` remains supported for compatibility.

## Important

`cards.yml` must be placed in the plugin data folder:

`plugins/RolCards/cards.yml`

If your build system does not package the root-level `cards.yml` into the JAR, copy the included `cards.yml` there manually on first install.

Stage 2 intentionally keeps the original Java-defined class cards and old `createdCards` format. The new loader adds configurable cards to the same class card lists, so existing gameplay remains compatible.
